import React, { useState, useEffect, useMemo } from 'react';

// --- Configuration & Constants ---
const STATUSES = ["Not Started", "Scripting", "Shooting", "Editing", "Review", "Scheduled", "Published"];
const PRIORITIES = ["High", "Medium", "Low"];
const VIDEOGRAPHERS = ["Alex Rivera", "Jordan Smith", "Sam Chen", "Casey Taylor", "Morgan Lee"];
const PLATFORMS = [
    { name: "YouTube", icon: "🔴", color: "bg-red-600", limit: 5000 },
    { name: "Instagram", icon: "📸", color: "bg-pink-600", limit: 2200 },
    { name: "TikTok", icon: "🎵", color: "bg-black", limit: 150 },
    { name: "LinkedIn", icon: "💼", color: "bg-blue-700", limit: 3000 }
];

const INITIAL_DATA = [
    {
        id: 1, title: "Eco-Friendly Tech Review", description: "Deep dive into sustainable gadgets.",
        category: "Tech", tags: ["tech", "green"], videographer: "Alex Rivera", priority: "High",
        status: "Published", shootDate: "2026-02-10", deadlineDate: "2026-02-18", publishDate: "2026-02-20",
        platforms: ["YouTube", "LinkedIn"], notes: "Focus on battery life.",
        assets: { script: "#", footage: "#", final: "#" },
        shootDetails: { location: "Studio A", equipment: ["Sony A7SIII", "Tripod"], shotList: "Intro, B-roll, Outro" },
        checklists: { thumbnail: true, caption: true, hashtags: true, cta: true }
    },
    {
        id: 2, title: "Morning Routine Vlog", description: "Lifestyle content for Gen Z.",
        category: "Lifestyle", tags: ["vlog", "routine"], videographer: "Jordan Smith", priority: "Medium",
        status: "Shooting", shootDate: "2026-02-22", deadlineDate: "2026-03-01", publishDate: "2026-03-05",
        platforms: ["Instagram", "TikTok"], notes: "Soft lighting requested.",
        assets: { script: "#", footage: "", final: "" },
        shootDetails: { location: "Home Loft", equipment: ["iPhone 15 Pro", "Gimbal"], shotList: "Coffee, Desktop, Sunset" },
        checklists: { thumbnail: false, caption: false, hashtags: false, cta: false }
    },
    {
        id: 3, title: "AI for Business 2026", description: "Automation tools breakdown.",
        category: "Education", tags: ["AI", "Business"], videographer: "Sam Chen", priority: "High",
        status: "Scripting", shootDate: "2026-02-25", deadlineDate: "2026-03-05", publishDate: "2026-03-10",
        platforms: ["YouTube", "LinkedIn"], notes: "Detailed screen recordings needed.",
        assets: { script: "#", footage: "", final: "" },
        shootDetails: { location: "Office", equipment: ["Pro Mic", "Screen Recorder"], shotList: "Intro, Demo, Summary" },
        checklists: { thumbnail: false, caption: false, hashtags: false, cta: false }
    },
    {
        id: 4, title: "Night Street Photography", description: "BTS of nighttime creative shoot.",
        category: "Art", tags: ["night", "photo"], videographer: "Casey Taylor", priority: "Low",
        status: "Editing", shootDate: "2026-02-15", deadlineDate: "2026-02-25", publishDate: "2026-02-28",
        platforms: ["Instagram"], notes: "Lofi soundtrack.",
        assets: { script: "#", footage: "#", final: "" },
        shootDetails: { location: "Downtown", equipment: ["Fuji X-T5"], shotList: "Neon, Puddles, Walking" },
        checklists: { thumbnail: true, caption: false, hashtags: true, cta: false }
    },
    {
        id: 5, title: "Real Estate Luxury Tour", description: "High-end property showcase.",
        category: "Real Estate", tags: ["luxury", "home"], videographer: "Morgan Lee", priority: "High",
        status: "Review", shootDate: "2026-02-12", deadlineDate: "2026-02-22", publishDate: "2026-02-24",
        platforms: ["YouTube", "Instagram"], notes: "Drone shots are key.",
        assets: { script: "#", footage: "#", final: "#" },
        shootDetails: { location: "Palm Jumeirah", equipment: ["RED Komodo", "Drone"], shotList: "Aerials, Interior sweep, Kitchen" },
        checklists: { thumbnail: true, caption: true, hashtags: false, cta: true }
    }
];

// --- Components ---

const Badge = ({ children, color = "bg-gray-100 text-black" }) => (
    <span className={`px-2 py-0.5 rounded-full text-[10px] font-normal tracking-widest border border-black/20 ${color}`}>
        {children}
    </span>
);

const PlatformIcon = ({ platform }) => {
    const p = PLATFORMS.find(x => x.name === platform);
    return <span title={platform} className="mr-1">{p ? p.icon : "🎥"}</span>;
};

// --- Main Application ---

export default function OSACMarketingHub() {
    const [contentItems, setContentItems] = useState(INITIAL_DATA);
    const [currentView, setCurrentView] = useState('dashboard');
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingItem, setEditingItem] = useState(null);
    const [searchQuery, setSearchQuery] = useState("");
    const [viewMode, setViewMode] = useState('grid');
    const [previewUrl, setPreviewUrl] = useState(null);
    const [previewName, setPreviewName] = useState("");

    const stats = useMemo(() => {
        const today = new Date();
        return {
            pipeline: contentItems.filter(i => i.status !== "Published").length,
            published: contentItems.filter(i => i.status === "Published" && new Date(i.publishDate).getMonth() === today.getMonth()).length,
            overdue: contentItems.filter(i => new Date(i.deadlineDate) < today && i.status !== "Published").length,
            review: contentItems.filter(i => i.status === "Review").length,
            workload: VIDEOGRAPHERS.map(v => ({
                name: v, count: contentItems.filter(i => i.videographer === v && i.status !== "Published").length
            })),
            funnel: STATUSES.map(s => ({
                status: s, count: contentItems.filter(i => i.status === s).length
            }))
        };
    }, [contentItems]);

    const filteredItems = useMemo(() => {
        return contentItems.filter(i => i.title.toLowerCase().includes(searchQuery.toLowerCase()) || i.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase())));
    }, [contentItems, searchQuery]);

    const handleStatusMove = (id, newStatus) => {
        setContentItems(contentItems.map(i => i.id === id ? { ...i, status: newStatus } : i));
    };

    const handleCreateOrUpdate = (e) => {
        e.preventDefault();
        const fd = new FormData(e.target);
        const activePlatforms = PLATFORMS.filter(p => fd.get(`platform-${p.name}`)).map(p => p.name);

        const newItem = {
            id: editingItem ? editingItem.id : Date.now(),
            title: fd.get('title'),
            description: fd.get('description'),
            category: fd.get('category'),
            tags: fd.get('tags').split(',').map(t => t.trim()),
            videographer: fd.get('videographer'),
            agentName: fd.get('agentName'),
            priority: fd.get('priority'),
            status: fd.get('status'),
            shootDate: fd.get('shootDate'),
            deadlineDate: fd.get('deadlineDate'),
            publishDate: fd.get('publishDate'),
            platforms: activePlatforms,
            notes: fd.get('notes'),
            assets: {
                script: fd.get('script'),
                scriptUrl: fd.get('scriptUrl'),
                footage: fd.get('footage'),
                final: fd.get('final')
            },
            shootDetails: editingItem ? editingItem.shootDetails : { location: "", equipment: [], shotList: "" },
            checklists: editingItem ? editingItem.checklists : { thumbnail: false, caption: false, hashtags: false, cta: false }
        };

        setContentItems(editingItem ? contentItems.map(i => i.id === editingItem.id ? newItem : i) : [newItem, ...contentItems]);
        setIsModalOpen(false);
        setEditingItem(null);
    };

    // --- Sub-Views ---

    const Dashboard = () => (
        <div className="space-y-8 animate-in font-poppins">
            <div className="grid grid-cols-4 gap-6">
                {[
                    { l: "Pipeline", v: stats.pipeline, c: "border-black" },
                    { l: "Month Published", v: stats.published, c: "border-gray-400" },
                    { l: "Overdue Items", v: stats.overdue, c: "border-red-600" },
                    { l: "Under Review", v: stats.review, c: "border-gray-200" }
                ].map((k, i) => (
                    <div key={i} className={`bg-white p-8 rounded-3xl border-l-[6px] ${k.c} shadow-xl shadow-gray-100 border border-gray-100`}>
                        <h4 className="text-[10px] font-normal text-gray-400 tracking-[0.3em] mb-2">{k.l}</h4>
                        <p className="text-3xl font-normal text-black">{k.v}</p>
                    </div>
                ))}
            </div>

            <div className="grid grid-cols-2 gap-8">
                <div className="bg-white p-10 rounded-[3rem] border border-gray-100 shadow-xl shadow-gray-100">
                    <h3 className="text-sm font-normal text-black tracking-widest mb-10">Production flow</h3>
                    <div className="space-y-4">
                        {stats.funnel.map((f, i) => (
                            <div key={i} className="flex items-center space-x-6">
                                <div className="w-28 text-[10px] font-normal text-gray-400">{f.status}</div>
                                <div className="flex-1 h-3 bg-gray-50 rounded-full overflow-hidden">
                                    <div className="h-full bg-black" style={{ width: `${(f.count / (contentItems.length || 1)) * 100}%` }}></div>
                                </div>
                                <div className="text-xs font-normal text-black">{f.count}</div>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="bg-white p-10 rounded-[3rem] border border-gray-100 shadow-xl shadow-gray-100 flex items-end justify-between h-[350px]">
                    {stats.workload.map((w, i) => (
                        <div key={i} className="flex flex-col items-center w-1/5 group">
                            <div className="w-12 bg-black/10 border border-black/20 rounded-t-xl transition-all hover:bg-black relative" style={{ height: `${(w.count / 5) * 100}%`, minHeight: '5px' }}>
                                <span className="absolute -top-8 left-1/2 -translate-x-1/2 text-[10px] font-normal opacity-0 group-hover:opacity-100 transition-opacity bg-black text-white px-2 py-1 rounded">
                                    {w.count}
                                </span>
                            </div>
                            <p className="text-[10px] font-normal text-gray-400 mt-4 rotate-[-45deg] whitespace-nowrap">{w.name.split(' ')[0]}</p>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );

    const CMS = () => {
        const KanbanBoard = () => (
            <div className="flex space-x-6 overflow-x-auto pb-8 custom-scrollbar">
                {STATUSES.map(status => (
                    <div key={status} className="flex-shrink-0 w-80 bg-gray-50 rounded-[2rem] p-6 border border-gray-100">
                        <h4 className="text-[10px] font-normal text-black tracking-[0.4em] mb-6 flex justify-between">
                            {status} <span className="text-gray-400">({contentItems.filter(i => i.status === status).length})</span>
                        </h4>
                        <div className="space-y-4">
                            {contentItems.filter(i => i.status === status).map(item => (
                                <div key={item.id} className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm group hover:border-[#B8860B]/40 transition-all">
                                    <div className="flex justify-between mb-3 text-[8px] font-normal text-gray-300">
                                        <span>{item.videographer}</span>
                                        <div className="text-[#B8860B] space-x-2">
                                            <button onClick={() => { setEditingItem(item); setIsModalOpen(true); }}>Edit</button>
                                        </div>
                                    </div>
                                    <h5 className="text-sm font-normal text-black leading-tight transition-colors">{item.title}</h5>
                                </div>
                            ))}
                        </div>
                    </div>
                ))}
            </div>
        );

        return (
            <div className="space-y-10 animate-in font-poppins font-normal">
                <div className="flex justify-between items-center gap-6">
                    <div className="flex-1 flex gap-4">
                        <input
                            placeholder="Search project data..."
                            className="bg-white border border-gray-100 rounded-2xl px-10 py-5 flex-1 focus:border-black outline-none font-normal text-xs tracking-[0.3em] transition-all shadow-sm text-black"
                            onChange={(e) => setSearchQuery(e.target.value)}
                        />
                        <button
                            onClick={() => setViewMode(viewMode === 'grid' ? 'kanban' : 'grid')}
                            className="bg-gray-50 border border-gray-100 text-gray-400 px-6 rounded-2xl font-normal text-[10px] hover:text-black transition-all"
                        >
                            {viewMode === 'grid' ? 'Kanban' : 'Grid'}
                        </button>
                    </div>
                    <button
                        onClick={() => { setEditingItem(null); setIsModalOpen(true); }}
                        className="bg-black text-white px-10 py-5 rounded-2xl font-normal text-xs tracking-widest shadow-xl shadow-black/20 hover:scale-[1.02] transition-all"
                    >
                        + New project
                    </button>
                </div>

                {viewMode === 'kanban' ? <KanbanBoard /> : (
                    <div className="grid grid-cols-3 gap-8">
                        {filteredItems.map(item => (
                            <div key={item.id} className="bg-white border border-gray-100 p-8 rounded-[2.5rem] shadow-xl shadow-gray-100 hover:border-[#B8860B]/50 transition-all group relative overflow-hidden">
                                <div className="flex justify-between items-start mb-6">
                                    <Badge color={item.priority === 'High' ? 'bg-red-50 text-red-600 border border-red-100' : 'bg-gray-50 text-black'}>{item.priority}</Badge>
                                    <span className="text-[10px] font-normal text-black">{item.status}</span>
                                </div>
                                <h4 className="text-xl font-normal tracking-tighter leading-tight text-black mb-2">{item.title}</h4>
                                <p className="text-gray-400 text-[10px] font-normal tracking-wide border-b border-gray-50 pb-6 mb-6 line-clamp-2">{item.description}</p>
                                <div className="flex justify-between items-center text-[9px] font-normal text-gray-300 tracking-widest mt-2">
                                    <div className="text-black opacity-60 font-normal">Agent: {item.agentName || "N/A"}</div>
                                </div>
                                <div className="flex justify-between items-center text-[9px] font-normal text-gray-300 tracking-widest mt-2 border-t border-gray-50 pt-2">
                                    <div className="flex flex-col">
                                        <div className="text-black opacity-60 font-normal">{item.videographer}</div>
                                        {item.assets?.script && (
                                            <button onClick={() => { setPreviewUrl(item.assets.scriptUrl); setPreviewName(item.assets.script); }} className="text-[#B8860B] underline mt-1 text-left">View script</button>
                                        )}
                                    </div>
                                    <div className="flex">
                                        {item.platforms.map(p => <PlatformIcon key={p} platform={p} />)}
                                    </div>
                                </div>
                                <button
                                    onClick={() => { setEditingItem(item); setIsModalOpen(true); }}
                                    className="absolute inset-0 bg-[#B8860B]/0 hover:bg-[#B8860B]/5 transition-all outline-none"
                                ></button>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        );
    };

    const ProductionManager = () => {
        const items = contentItems.filter(i => i.status !== 'Published');
        return (
            <div className="grid grid-cols-2 gap-8 animate-in font-poppins font-normal">
                {items.length === 0 && <p className="text-gray-300 font-normal tracking-widest">No active productions recorded.</p>}
                {items.map(item => (
                    <div key={item.id} className="bg-white p-12 rounded-[3.5rem] border border-gray-100 shadow-2xl shadow-gray-100 space-y-8 relative overflow-hidden transition-all hover:border-black/20">
                        <div className="flex justify-between items-start">
                            <div className="flex-1">
                                <h4 className="text-[10px] font-normal text-gray-400 tracking-widest mb-1 border-b border-gray-50 pb-2">Topic / Project</h4>
                                <h3 className="text-2xl font-normal tracking-tighter text-black leading-tight mt-2">{item.title}</h3>
                            </div>
                        </div>

                        <div className="grid grid-cols-2 gap-6">
                            <div className="bg-gray-50 p-6 rounded-3xl border border-gray-100">
                                <h5 className="text-[9px] font-normal text-black tracking-widest mb-3">Agent in video</h5>
                                <p className="text-sm font-normal text-black">{item.agentName || "N/A"}</p>
                            </div>
                            <div className="bg-gray-50 p-6 rounded-3xl border border-gray-100">
                                <h5 className="text-[9px] font-normal text-black tracking-widest mb-3">Content creator</h5>
                                <p className="text-sm font-normal text-black">{item.videographer}</p>
                            </div>
                            <div className="bg-gray-50 p-6 rounded-3xl border border-gray-100">
                                <h5 className="text-[9px] font-normal text-black tracking-widest mb-3">Finish target</h5>
                                <p className="text-sm font-normal text-black">{item.deadlineDate || "TBD"}</p>
                            </div>
                        </div>

                        <div className="space-y-4">
                            <h5 className="text-[9px] font-normal text-black tracking-widest">Current phase</h5>
                            <select
                                value={item.status}
                                onChange={(e) => handleStatusMove(item.id, e.target.value)}
                                className="w-full bg-white border border-gray-100 rounded-2xl px-6 py-4 outline-none font-normal text-xs text-black tracking-widest shadow-sm focus:border-black transition-all"
                            >
                                {STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                            </select>
                        </div>

                        <div className="pt-4 flex justify-between items-center border-t border-gray-50">
                            <p className="text-[9px] text-gray-300 tracking-widest leading-none">System tracking enabled</p>
                            <button onClick={() => { setEditingItem(item); setIsModalOpen(true); }} className="text-[10px] text-black border-b border-black font-normal">Edit details</button>
                        </div>
                    </div>
                ))}
            </div>
        );
    }

    const EditorialCalendar = () => {
        const [viewDate, setViewDate] = useState(new Date());
        const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

        const daysInMonth = new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 0).getDate();
        const startDay = new Date(viewDate.getFullYear(), viewDate.getMonth(), 1).getDay();
        const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
        const placeholders = Array.from({ length: startDay }, (_, i) => i);

        return (
            <div className="animate-in bg-white border border-gray-100 rounded-[3rem] p-12 h-[800px] flex flex-col font-poppins font-normal shadow-2xl shadow-gray-50">
                <div className="flex justify-between items-center mb-10 border-b border-gray-50 pb-8">
                    <h3 className="text-2xl font-normal text-black tracking-widest">{monthNames[viewDate.getMonth()]} {viewDate.getFullYear()}</h3>
                    <div className="space-x-4">
                        <button onClick={() => setViewDate(new Date(viewDate.setMonth(viewDate.getMonth() - 1)))} className="px-6 py-3 border border-gray-100 rounded-xl hover:bg-black hover:text-white transition-all text-xs font-normal">Prev</button>
                        <button onClick={() => setViewDate(new Date(viewDate.setMonth(viewDate.getMonth() + 1)))} className="px-6 py-3 border border-gray-100 rounded-xl hover:bg-black hover:text-white transition-all text-xs font-normal">Next</button>
                    </div>
                </div>
                <div className="grid grid-cols-7 border-b border-gray-50 pb-6 mb-6">
                    {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(d => (
                        <div key={d} className="text-center text-[10px] font-normal text-gray-400 tracking-widest">{d}</div>
                    ))}
                </div>
                <div className="flex-1 grid grid-cols-7 gap-4">
                    {placeholders.map(p => <div key={`p-${p}`} className="p-4 opacity-0"></div>)}
                    {days.map(d => {
                        const dateStr = `${viewDate.getFullYear()}-${String(viewDate.getMonth() + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
                        const dayItems = contentItems.filter(it => it.publishDate === dateStr || it.deadlineDate === dateStr);
                        return (
                            <div key={d} className="border border-gray-50 rounded-2xl p-4 hover:bg-gray-50 transition-all group relative min-h-[100px] overflow-y-auto custom-scrollbar">
                                <span className="text-gray-300 font-normal text-xs group-hover:text-black">{d}</span>
                                <div className="mt-2 space-y-1">
                                    {dayItems.map(it => (
                                        <div key={it.id} className={`text-[8px] p-2 rounded-lg border font-normal truncate tracking-tighter ${it.status === 'Published' ? 'bg-gray-100 border-gray-200 text-gray-400' : 'bg-black/5 border-black/10 text-black'}`}>
                                            [{it.status === 'Published' ? 'Pub' : 'Target'}] {it.title}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        );
    }

    const TeamTracker = () => (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 animate-in text-center font-poppins font-normal">
            {VIDEOGRAPHERS.map(v => {
                const assigned = contentItems.filter(i => i.videographer === v);
                const pub = assigned.filter(i => i.status === 'Published').length;
                const rate = assigned.length ? Math.round((pub / assigned.length) * 100) : 0;
                return (
                    <div key={v} className="bg-white p-12 rounded-[3.5rem] border border-gray-100 shadow-xl shadow-gray-100 relative group border border-gray-100 shadow-xl relative group">
                        <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#B8860B] to-[#D4AF37] mx-auto mb-10 border-[6px] border-white shadow-xl flex items-center justify-center text-4xl font-normal italic text-white">
                            {v[0]}
                        </div>
                        <h3 className="text-2xl font-normal text-black tracking-tighter">{v}</h3>
                        <div className="mt-8 space-y-1 text-gray-400 text-[10px] font-normal tracking-widest">
                            <p>Projects: {assigned.length}</p>
                            <p>Efficiency: <span className="text-[#B8860B] font-normal">{rate}%</span></p>
                        </div>
                        <div className="mt-10 h-1 bg-gray-50 rounded-full overflow-hidden w-2/3 mx-auto">
                            <div className="h-full bg-black" style={{ width: `${rate}%` }}></div>
                        </div>
                    </div>
                );
            })}
        </div>
    );

    // --- Layout ---

    return (
        <div className="min-h-screen bg-white text-black font-poppins font-normal flex selection:bg-black selection:text-white">
            {/* Sidebar */}
            <nav className="w-80 bg-white border-r border-gray-100 flex flex-col fixed inset-y-0 z-50 shadow-sm">
                <div className="p-12 border-b border-gray-50">
                    <h1 className="text-lg font-normal text-black tracking-widest leading-none">
                        Osac <span className="text-gray-900 opacity-20">Marketing</span> Team
                    </h1>
                </div>

                <div className="flex-1 px-8 space-y-2 mt-12">
                    {[
                        { id: 'dashboard', label: 'OVERVIEW' },
                        { id: 'cms', label: 'MEDIA LIBRARY' },
                        { id: 'shooting', label: 'PRODUCTION' },
                        { id: 'calendar', label: 'EDITORIAL' },
                        { id: 'team', label: 'THE FLEET' },
                    ].map(item => (
                        <button
                            key={item.id}
                            onClick={() => setCurrentView(item.id)}
                            className={`w-full flex items-center justify-center px-10 py-5 rounded-3xl font-normal transition-all text-[10px] tracking-[0.3em] ${currentView === item.id ? 'bg-black text-white shadow-xl shadow-black/20' : 'text-gray-300 hover:text-black hover:bg-gray-50'}`}
                        >
                            {item.label}
                        </button>
                    ))}
                    <button
                        onClick={() => document.getElementById('sidebarScriptAttachment').click()}
                        className="w-full flex items-center justify-center px-10 py-5 rounded-3xl font-normal transition-all text-[10px] tracking-[0.3em] text-gray-300 hover:text-black hover:bg-gray-50 mt-10 border border-dashed border-gray-200 group"
                    >
                        UPLOAD SCRIPT
                        <input
                            type="file"
                            id="sidebarScriptAttachment"
                            className="hidden"
                            onChange={(e) => {
                                const name = e.target.files[0]?.name;
                                if (name) alert(`Script "${name}" attached to operations.`);
                            }}
                        />
                    </button>
                </div>

                <div className="p-12 border-t border-gray-50">
                    <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 rounded-full bg-gray-50 border border-black/20 flex items-center justify-center font-normal text-black">OM</div>
                        <p className="text-[10px] font-normal text-black opacity-40">Live system</p>
                    </div>
                </div>
            </nav>

            {/* Main Content */}
            <main className="flex-1 ml-80 p-20 max-w-[1700px]">
                <header className="mb-24 flex justify-between items-end border-b border-gray-100 pb-12">
                    <div className="space-y-6">
                        <h2 className="text-5xl font-normal text-black tracking-tighter">
                            {currentView === 'cms' ? 'Media library' : currentView === 'shooting' ? 'Production' : (currentView.charAt(0).toUpperCase() + currentView.slice(1))}
                        </h2>
                        <p className="text-[12px] text-gray-400 mt-6 tracking-[0.5em] font-bold uppercase">Content operations</p>
                    </div>
                    <div className="text-right">
                        <p className="text-[10px] font-normal text-gray-300 tracking-[0.6em] mb-4 leading-none">Clearance</p>
                        <p className="text-2xl font-normal text-black tracking-tighter">Elite tier</p>
                    </div>
                </header>

                {currentView === 'dashboard' && <Dashboard />}
                {currentView === 'cms' && <CMS />}
                {currentView === 'shooting' && <ProductionManager />}
                {currentView === 'calendar' && <EditorialCalendar />}
                {currentView === 'team' && <TeamTracker />}
            </main>

            {/* Project Modal */}
            {isModalOpen && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-12 bg-white/95 backdrop-blur-xl animate-in font-poppins font-normal">
                    <div className="bg-white border border-[#B8860B]/20 rounded-[4rem] w-full max-w-4xl p-20 shadow-2xl relative h-[90vh] overflow-y-auto custom-scrollbar">
                        <button onClick={() => setIsModalOpen(false)} className="absolute top-10 right-10 text-4xl text-black hover:scale-110 transition-all font-normal">&times;</button>
                        <h2 className="text-5xl font-normal text-black mb-12 tracking-tighter">Production details</h2>

                        <form className="space-y-12" onSubmit={handleCreateOrUpdate}>
                            <div className="space-y-4">
                                <label className="text-[10px] font-normal text-black tracking-widest ml-1">Content topic / title</label>
                                <input name="title" defaultValue={editingItem?.title} required placeholder="Enter topic..." className="w-full bg-gray-50 border border-gray-100 rounded-3xl px-10 py-6 focus:border-black outline-none font-normal text-sm text-black tracking-[0.2em]" />
                            </div>

                            <div className="grid grid-cols-2 gap-8">
                                <div className="space-y-4">
                                    <label className="text-[10px] font-normal text-black tracking-widest">Content creator (Content operative)</label>
                                    <select name="videographer" defaultValue={editingItem?.videographer} className="w-full bg-gray-50 border border-gray-100 rounded-3xl px-8 py-6 outline-none font-normal text-xs text-black">
                                        {VIDEOGRAPHERS.map(v => <option key={v}>{v}</option>)}
                                    </select>
                                </div>
                                <div className="space-y-4">
                                    <label className="text-[10px] font-normal text-black tracking-widest">Agent name (In video)</label>
                                    <input name="agentName" defaultValue={editingItem?.agentName} placeholder="Enter agent name..." className="w-full bg-gray-50 border border-gray-100 rounded-3xl px-8 py-6 focus:border-black outline-none font-normal text-sm text-black tracking-[0.2em]" />
                                </div>
                                <div className="space-y-4">
                                    <label className="text-[10px] font-normal text-black tracking-widest">Completion target date</label>
                                    <input type="date" name="deadlineDate" defaultValue={editingItem?.deadlineDate} className="w-full bg-gray-50 border border-gray-100 rounded-3xl px-8 py-6 outline-none font-normal text-xs text-black" />
                                </div>
                            </div>

                            <div className="space-y-4">
                                <label className="text-[10px] font-normal text-black tracking-widest">Production phase</label>
                                <select name="status" defaultValue={editingItem?.status} className="w-full bg-gray-50 border border-gray-100 rounded-3xl px-8 py-6 outline-none font-normal text-xs text-black">
                                    {STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                                </select>
                            </div>                            <div className="space-y-4">
                                <label className="text-[10px] font-normal text-black tracking-widest">Script attachment</label>
                                <div className="relative">
                                    <input
                                        type="file"
                                        name="scriptFile"
                                        id="modalScriptAttachment"
                                        className="hidden"
                                        onChange={(e) => {
                                            const file = e.target.files[0];
                                            if (file) {
                                                const reader = new FileReader();
                                                reader.onloadend = () => {
                                                    document.getElementById('modal-file-display').textContent = `Attached: ${file.name}`;
                                                    document.getElementsByName('script')[0].value = file.name;
                                                    document.getElementsByName('scriptUrl')[0].value = reader.result;
                                                    // Trigger React refresh if needed, but for now we use hidden inputs for form submission
                                                };
                                                reader.readAsDataURL(file);
                                            }
                                        }}
                                    />
                                    <label
                                        htmlFor="modalScriptAttachment"
                                        className="w-full bg-gray-50 border border-dashed border-gray-200 rounded-3xl px-10 py-10 flex flex-col items-center justify-center cursor-pointer hover:border-black hover:bg-gray-100 transition-all group overflow-hidden"
                                    >
                                        {editingItem?.assets?.scriptUrl && editingItem.assets.scriptUrl.startsWith('data:image') ? (
                                            <img src={editingItem.assets.scriptUrl} className="max-w-[200px] h-auto rounded-xl shadow-sm mb-4" alt="Preview" />
                                        ) : <span className="text-3xl mb-3 group-hover:scale-110 transition-transform">📎</span>}

                                        <span id="modal-file-display" className="text-[10px] tracking-widest text-gray-400 group-hover:text-black">
                                            {editingItem?.assets?.script && editingItem.assets.script !== '#' ? `Attached: ${editingItem.assets.script}` : "Upload script for this production"}
                                        </span>
                                    </label>
                                    <input type="hidden" name="script" defaultValue={editingItem?.assets?.script || ''} />
                                    <input type="hidden" name="scriptUrl" defaultValue={editingItem?.assets?.scriptUrl || ''} />
                                </div>
                            </div>
                            <div className="flex gap-8 pt-12">
                                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 py-6 font-normal text-gray-300 tracking-widest text-[10px] hover:text-black">Abort</button>
                                <button type="submit" className="flex-1 bg-black text-white py-6 rounded-3xl font-normal tracking-[0.5em] shadow-2xl shadow-black/40 text-[10px] hover:scale-[1.02] transition-all">Save work</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* Preview Modal */}
            {previewUrl && (
                <div className="fixed inset-0 z-[200] flex items-center justify-center p-12 bg-black/95 backdrop-blur-3xl animate-in font-poppins">
                    <button onClick={() => setPreviewUrl(null)} className="absolute top-10 right-10 text-white text-5xl font-light hover:scale-110 transition-all">&times;</button>
                    <div className="w-full max-w-5xl flex flex-col items-center">
                        <p className="text-white text-[10px] tracking-[0.5em] mb-10 opacity-50 font-medium whitespace-nowrap overflow-hidden text-ellipsis">Viewing attached file: {previewName}</p>
                        <div className="bg-white rounded-[2rem] shadow-2xl w-full max-h-[80vh] overflow-y-auto custom-scrollbar flex flex-col items-center p-4">
                            {previewName.toLowerCase().match(/\.(jpg|jpeg|png|gif|webp)$/) || previewUrl.startsWith('data:image') ? (
                                <img src={previewUrl} className="w-full h-auto rounded-xl shadow-sm" alt="Preview" />
                            ) : (
                                <div className="p-20 text-center">
                                    <p className="text-2xl tracking-tighter mb-8 text-black">Document preview not available</p>
                                    <a href={previewUrl} download={previewName} className="bg-black text-white px-10 py-5 rounded-2xl text-[10px] tracking-widest font-normal">Download to view</a>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {/* Global Style */}
            <style dangerouslySetInnerHTML={{
                __html: `
                @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap');
                * { font-weight: 400 !important; font-style: normal !important; color: black; }
                .font-poppins { font-family: 'Poppins', sans-serif !important; }
                .custom-scrollbar::-webkit-scrollbar { width: 6px; height: 6px; }
                .custom-scrollbar::-webkit-scrollbar-track { background: white; }
                .custom-scrollbar::-webkit-scrollbar-thumb { background: #f3f4f6; border-radius: 10px; }
                .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: black; }
                @keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
                .animate-in { animation: fadeIn 0.8s cubic-bezier(0.16, 1, 0.3, 1); }
            `}} />
        </div>
    );
}
